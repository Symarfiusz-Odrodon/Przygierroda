import "./podstrony.css";

const WesprzyjNas = () => {
    return (
        <div className="zawartośćPodstrony">
            <h1>To jest podstrona dla skorych do pomocy!</h1>
        </div>
    )
};

export default WesprzyjNas;