import "./podstrony.css";

const Praca = () => {
    return (
        <div className="zawartośćPodstrony">
            <h1>To jest podstrona dla ludzi z dwoma rękoma gotowymi do pracy!</h1>
        </div>
    )
};

export default Praca;