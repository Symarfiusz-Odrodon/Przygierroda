import "./podstrony.css";

const Regulamin = () => {
    return (
        <div className="zawartośćPodstrony">
            <h1>To jest podstrona dla oczytanych!</h1>
        </div>
    )
};

export default Regulamin;